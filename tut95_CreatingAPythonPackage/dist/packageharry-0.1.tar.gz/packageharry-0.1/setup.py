from ast import keyword
from setuptools import setup, find_packages

setup(name='packageharry',
version='0.1',
description='this is code a simple package to return a number',
long_description='this is a very very long description',
author='sambhav kaushik',
keyword='number',
packages=['packageSam'],
install_requires=[]
)