def achhafunc(number):
    print('this is a function')
    return number
